%XMLSAVE save variables to file in xml format.
%    XMLSAVE(filename,variable1,variable2,variable3,...) save variables
%    into filename.
% 
%    See also vartostruct

%   Author(s): M. Kutil
%   Copyright (c) 2005
%   $Revision: 1896 $  $Date: 2007-10-12 08:13:54 +0200 (p, 12 X 2007) $


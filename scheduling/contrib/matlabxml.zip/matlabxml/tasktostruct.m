%TASKTOSTRUCT convert taskset object to struct.
%    struct = TASKTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml, task (scheduling toolbox)

%   Author(s): M. Kutil
%   Copyright (c) 2005
%   $Revision: 1896 $  $Date: 2007-10-12 08:13:54 +0200 (p, 12 X 2007) $


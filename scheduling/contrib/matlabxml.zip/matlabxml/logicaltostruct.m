%CHARTOSTRUCT convert logical to struct.
%    struct = LOGICALTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml

%   Author(s): P. Sucha
%   Copyright (c) 2006
%   $Revision: 1896 $  $Date: 2007-10-12 08:13:54 +0200 (p, 12 X 2007) $


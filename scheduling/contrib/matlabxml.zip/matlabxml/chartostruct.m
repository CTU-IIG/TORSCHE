%CHARTOSTRUCT convert char to struct.
%    struct = CHARTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml

%   Author(s): M. Kutil
%   Copyright (c) 2005
%   $Revision: 1896 $  $Date: 2007-10-12 08:13:54 +0200 (p, 12 X 2007) $


%EDGETOSTRUCT convert edge object to struct.
%    struct = EDGETOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml, edge (scheduling toolbox)

%   Author(s): M. Kutil, V. Navratil
%   Copyright (c) 2005
%   $Revision: 1896 $  $Date: 2007-10-12 08:13:54 +0200 (p, 12 X 2007) $

